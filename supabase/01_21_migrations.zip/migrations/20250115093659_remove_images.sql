alter table "private_ci2027_001"."cluster" add column "irgendwas" text;


