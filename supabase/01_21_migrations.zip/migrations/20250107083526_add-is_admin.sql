alter table "public"."users_profile" add column "is_admin" boolean not null default false;


